class Todo {
  String uid;
  String title;
  bool isComplet;

  Todo({this.uid, this.title, this.isComplet});
}
